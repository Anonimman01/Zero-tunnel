
import React, { useState, useEffect, useRef } from 'react';
import { AppState, GhostAction, SecurityEvent } from '../types';
import { sanitizeAndProject, generateSpeech, decodeBase64, decodeAudioData, generateVisualMockup, BREACH_LOG_SEQUENCE, deepLogicScan, generateExploitPlan } from '../services/geminiService';

interface GhostWindowProps {
  state: AppState;
  onAction: (action: Omit<GhostAction, 'timestamp' | 'delayApplied'>) => void;
  onSecurityThreat: (source: string, type?: SecurityEvent['type']) => void;
}

export const GhostWindow: React.FC<GhostWindowProps> = ({ state, onAction, onSecurityThreat }) => {
  const [viewMode, setViewMode] = useState<'tunnel' | 'projection'>('tunnel');
  const [iframeKey, setIframeKey] = useState(0);
  const [showXFrameWarning, setShowXFrameWarning] = useState(false);
  const [isProbing, setIsProbing] = useState(false);
  
  const [projectionData, setProjectionData] = useState<string | null>(null);
  const [citations, setCitations] = useState<any[]>([]);
  const [isProjecting, setIsProjecting] = useState(false);
  const [breachLogs, setBreachLogs] = useState<string[]>([]);
  
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [mockupUrl, setMockupUrl] = useState<string | null>(null);
  const [isGeneratingMockup, setIsGeneratingMockup] = useState(false);
  
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [exploitPlan, setExploitPlan] = useState<string | null>(null);
  const [isPlanning, setIsPlanning] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    if (!state.isActive) return;
    setIframeKey(prev => prev + 1);
    setViewMode('tunnel');
    setShowXFrameWarning(false);
    setProjectionData(null);
    setScanResult(null);
    setExploitPlan(null);
    setCitations([]);
    setMockupUrl(null);
    setBreachLogs([]);
    stopAudio();
    setIsProbing(true);
    
    const probeTimer = setTimeout(() => {
      setIsProbing(false);
      const url = (state.currentUrl || "").toLowerCase();
      const isGithub = url.includes('github.com');
      const likelyBlocked = isGithub || url.includes('reddit.com') || url.includes('twitter.com') || url.includes('x.com') || url.includes('google.com');

      if (likelyBlocked) {
        setShowXFrameWarning(true);
        onSecurityThreat(`${isGithub ? 'GitHub Perimeter Shield' : 'Perimeter Block'} detected at ${url.split('/')[2]}`, 'HEADER_STRIPPED');
      }
    }, 1800);

    return () => clearTimeout(probeTimer);
  }, [state.currentUrl, state.isActive]);

  const stopAudio = () => {
    if (audioSourceRef.current) {
      try { audioSourceRef.current.stop(); } catch(e) {}
      audioSourceRef.current = null;
    }
    setIsSpeaking(false);
  };

  const handleExploitPlanning = async () => {
    if (!scanResult || isPlanning) return;
    setIsPlanning(true);
    setExploitPlan(null);
    try {
      const plan = await generateExploitPlan(scanResult);
      setExploitPlan(plan);
      handleSpeech(plan);
    } catch (e) {
      setExploitPlan("## PLANNING_FAILED");
    } finally {
      setIsPlanning(false);
    }
  };

  const triggerProjection = async () => {
    setViewMode('projection');
    if (projectionData) return;
    setIsProjecting(true);
    setBreachLogs([]);
    
    let logIndex = 0;
    const logInterval = setInterval(() => {
      if (logIndex < BREACH_LOG_SEQUENCE.length) {
        setBreachLogs(prev => [...prev, BREACH_LOG_SEQUENCE[logIndex]]);
        logIndex++;
      } else {
        clearInterval(logInterval);
      }
    }, 350);

    try {
      const result = await sanitizeAndProject(state.currentUrl);
      setProjectionData(result.text);
      setCitations(result.citations || []);
      if (result.text) {
        setIsScanning(true);
        const audit = await deepLogicScan(result.text);
        setScanResult(audit);
        setIsScanning(false);
      }
    } catch (e) {
      setProjectionData("## BREACH_STALLED");
    } finally {
      setIsProjecting(false);
    }
  };

  const handleSpeech = async (text?: string) => {
    if (isSpeaking) { stopAudio(); return; }
    const content = text || scanResult || projectionData;
    if (!content) return;
    setIsSpeaking(true);
    try {
      const audioBase64 = await generateSpeech(content);
      if (!audioContextRef.current) audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      const buffer = await decodeAudioData(decodeBase64(audioBase64), audioContextRef.current);
      const source = audioContextRef.current.createBufferSource();
      source.buffer = buffer; source.connect(audioContextRef.current.destination);
      source.onended = () => setIsSpeaking(false);
      source.start(); audioSourceRef.current = source;
    } catch (e) { setIsSpeaking(false); }
  };

  const handleMockup = async () => {
    if (isGeneratingMockup) return;
    setIsGeneratingMockup(true);
    try {
      const url = await generateVisualMockup(exploitPlan || scanResult || "");
      setMockupUrl(url);
    } catch (e) { console.error(e); } finally { setIsGeneratingMockup(false); }
  };

  const parseExploitSteps = (plan: string) => {
    const steps = plan.split(/STEP \d+:/).filter(s => s.trim().length > 0);
    return steps.map(s => {
      const lines = s.trim().split('\n');
      const title = lines[0].replace(/\[|\]/g, '').trim();
      const objective = s.match(/- OBJECTIVE: (.*)/)?.[1] || "";
      const payload = s.match(/- PAYLOAD_STRATEGY: (.*)/)?.[1] || "";
      const result = s.match(/- EXPECTED_RESULT: (.*)/)?.[1] || "";
      const risk = s.match(/- DETECTION_RISK: (.*)/)?.[1] || "MEDIUM";
      return { title, objective, payload, result, risk: risk.toUpperCase() };
    });
  };

  const displayDomain = (state.currentUrl || "").split('/')[2] || "unknown";
  const isGithub = (state.currentUrl || "").includes('github.com');

  return (
    <div className="h-full w-full relative bg-black flex flex-col rounded-xl border border-zinc-800 shadow-2xl overflow-hidden group">
      <div className="h-10 bg-zinc-950 border-b border-zinc-900 flex items-center justify-between px-4 z-40">
        <div className="flex items-center gap-4">
           <span className={`text-[9px] mono font-black uppercase px-2 py-0.5 rounded border ${isGithub ? 'text-purple-400 bg-purple-500/5 border-purple-500/10 shadow-[0_0_10px_rgba(168,85,247,0.1)]' : 'text-blue-500 bg-blue-500/5 border-blue-500/10'}`}>
             Node::{displayDomain}
           </span>
           <span className={`text-[8px] bg-zinc-900 px-2 py-0.5 rounded font-black border border-zinc-800 uppercase tracking-widest ${isGithub ? 'text-purple-500' : 'text-zinc-600'}`}>
             {isGithub ? 'Protocol: SHOREDITCH_GHOST v6.5' : 'Breach_Mode: Red_Spear'}
           </span>
        </div>
        <div className="flex bg-zinc-900 p-0.5 rounded-lg border border-zinc-800">
          <button onClick={() => setViewMode('tunnel')} className={`px-4 py-1 text-[9px] font-black rounded ${viewMode === 'tunnel' ? 'bg-zinc-700 text-white shadow-inner' : 'text-zinc-500 hover:text-zinc-300'}`}>TUNNEL</button>
          <button onClick={triggerProjection} className={`px-4 py-1 text-[9px] font-black rounded ${viewMode === 'projection' ? 'bg-zinc-700 text-white shadow-inner' : 'text-zinc-500 hover:text-zinc-300'}`}>MIRROR</button>
        </div>
      </div>

      <div className="flex-1 relative bg-black overflow-hidden">
        {isProbing && (
          <div className="absolute inset-0 z-50 bg-black/95 flex flex-col items-center justify-center space-y-6 backdrop-blur-md">
             <div className={`w-16 h-16 border-b-4 ${isGithub ? 'border-purple-500 shadow-[0_0_20px_rgba(168,85,247,0.5)]' : 'border-blue-500'} rounded-full animate-spin`}></div>
             <p className={`text-[10px] font-black ${isGithub ? 'text-purple-500' : 'text-blue-500'} tracking-[0.5em] uppercase italic animate-pulse`}>
               {isGithub ? 'Engaging Shoreditch Ghost v6.5' : 'Engaging Shoreditch Relay v6.2'}
             </p>
          </div>
        )}

        {viewMode === 'tunnel' ? (
          <>
            <div className="absolute inset-0 bg-white"></div>
            <iframe key={iframeKey} src={state.currentUrl} className="w-full h-full border-none bg-white relative z-10" />
            {showXFrameWarning && (
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center bg-zinc-950/98 backdrop-blur-3xl p-12 text-center animate-in zoom-in-95 duration-700">
                <div className={`absolute inset-0 opacity-30 pointer-events-none ${isGithub ? 'ghost-rain-container' : 'header-rain-container'}`}></div>
                <div className={`w-20 h-20 border ${isGithub ? 'border-purple-600/50 text-purple-500 shadow-[0_0_40px_rgba(168,85,247,0.4)]' : 'border-red-600/50 text-red-500'} rounded-2xl flex items-center justify-center mb-8 shadow-2xl relative overflow-hidden group/warning`}>
                   <div className={`absolute inset-0 ${isGithub ? 'bg-purple-600/20' : 'bg-red-600/20'} blur-xl animate-pulse`}></div>
                  <svg className="w-10 h-10 relative group-hover/warning:scale-110 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                </div>
                <h3 className="text-white font-black text-2xl uppercase tracking-tighter mb-4 italic">
                  {isGithub ? 'GitHub Perimeter Shield' : 'Perimeter Hard_Block'}
                </h3>
                <p className="text-zinc-600 text-[10px] max-w-sm leading-relaxed mb-10 font-bold uppercase tracking-widest px-6 border-l-2 border-red-600/40">
                  {isGithub ? 'GitHub strict CSP detected. Deploying Shoreditch Ghost v6.5 for 100% anonymous neural reconstruction.' : 'The target host restricted framed access. Initiating Shadow Breach...'}
                </p>
                <button onClick={triggerProjection} className={`group relative px-12 py-4 ${isGithub ? 'bg-purple-700 hover:bg-purple-600 shadow-purple-900/40' : 'bg-blue-700 hover:bg-blue-600 shadow-blue-900/40'} text-white rounded-xl font-black text-[11px] tracking-[0.4em] uppercase transition-all shadow-xl active:scale-95 overflow-hidden`}>
                   {isGithub ? 'Deploy Ghost Protocol' : 'Initiate Shadow Breach'}
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="w-full h-full bg-zinc-950 overflow-y-auto custom-scrollbar relative selection:bg-purple-600/40">
            {/* Neural Sanitizer Overlay Effect - Stronger in Ghost Mode */}
            <div className={`absolute inset-0 pointer-events-none z-30 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] animate-pulse ${isGithub ? 'opacity-25' : ''}`}></div>
            
            {isProjecting ? (
              <div className="h-full w-full py-24 flex flex-col items-center justify-center gap-12">
                <div className="w-full max-w-lg bg-zinc-900/50 border border-zinc-800 rounded-2xl p-6 font-mono text-[10px] space-y-2 h-64 overflow-y-auto shadow-2xl backdrop-blur-md">
                   <p className="text-zinc-600 mb-4 border-b border-zinc-800 pb-2 uppercase font-black tracking-widest">
                     {isGithub ? 'Ghost_Breach_Terminal v6.5' : 'Breach_Console v6.2'}
                   </p>
                   {breachLogs.map((log, i) => (
                       <div key={i} className="flex gap-4 animate-in slide-in-from-left-2 fade-in duration-300">
                          <span className="text-zinc-700">[{new Date().toLocaleTimeString([], { hour12: false })}]</span>
                          <span className={`${(log || "").includes('READY') ? 'text-green-500' : (log || "").includes('ACTION') ? 'text-blue-400' : (log || "").includes('ANONYMITY') ? 'text-purple-400' : 'text-zinc-400'}`}>{log}</span>
                       </div>
                   ))}
                   <div className={`w-2 h-4 ${isGithub ? 'bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,0.8)]' : 'bg-blue-500'} opacity-50 animate-pulse mt-2 inline-block`}></div>
                </div>
              </div>
            ) : (
              <div className="p-12 space-y-20 max-w-7xl mx-auto animate-in fade-in duration-1000 pb-40 relative z-20">
                <div className="flex justify-between items-end border-b-2 border-zinc-900 pb-10">
                   <div className="space-y-4">
                      <h2 className={`text-white text-7xl font-black tracking-tighter italic uppercase leading-none ${isGithub ? 'text-transparent bg-clip-text bg-gradient-to-r from-white via-purple-400 to-white' : ''}`}>
                        {isGithub ? 'Ghost_Mirror' : 'Mirror_Projection'}
                      </h2>
                      <p className="text-zinc-700 text-[11px] font-black uppercase tracking-[0.6em]">
                        Target: {displayDomain} // {isGithub ? 'Status: 100% Invisible' : 'Op: Red_Spear'}
                      </p>
                   </div>
                   <div className="flex gap-4">
                      <div className="flex flex-col items-end justify-center px-6 border-r border-zinc-900">
                         <p className="text-[8px] text-zinc-600 font-black uppercase tracking-widest mb-1">Identity Entropy</p>
                         <p className="text-purple-500 text-xl font-black mono leading-none drop-shadow-[0_0_5px_rgba(168,85,247,0.5)]">1.00 <span className="text-[10px] text-zinc-700">MAX</span></p>
                      </div>
                      <button onClick={handleExploitPlanning} disabled={!scanResult || isPlanning} className={`px-8 py-4 rounded-xl border font-black text-[11px] tracking-widest uppercase transition-all ${isPlanning ? 'bg-red-600/20 text-red-500 border-red-500/50 animate-pulse' : 'bg-red-950/20 border-red-900/30 text-red-500 hover:bg-red-600 hover:text-white shadow-[0_0_20px_rgba(255,0,0,0.1)]'}`}>
                         {isPlanning ? 'Analyzing Vectors...' : 'Mission Briefing'}
                      </button>
                      <button onClick={handleMockup} className="p-4 rounded-xl border bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-white transition-all"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg></button>
                   </div>
                </div>

                {exploitPlan && (
                  <div className="space-y-12 animate-in slide-in-from-bottom-10 duration-700">
                    <div className="flex items-center justify-between bg-red-950/10 border border-red-900/30 p-8 rounded-[2.5rem] backdrop-blur-sm">
                       <div className="flex items-center gap-6">
                          <div className="w-12 h-12 bg-red-600/20 rounded-full flex items-center justify-center border border-red-600/30 animate-pulse">
                             <div className="w-4 h-4 bg-red-600 rounded-sm rotate-45"></div>
                          </div>
                          <div>
                             <h3 className="text-white text-2xl font-black uppercase tracking-tighter italic">Operation: Red_Spear Briefing</h3>
                             <p className="text-red-500/60 text-[10px] font-black uppercase tracking-[0.4em]">Breach Stability: High // Anonymity: 100% Guaranteed</p>
                          </div>
                       </div>
                       <div className="grid grid-cols-2 gap-10">
                          <div className="text-right">
                             <p className="text-zinc-600 text-[9px] font-black uppercase tracking-widest mb-1">Success Prob.</p>
                             <p className="text-white text-xl font-mono font-black">98.1%</p>
                          </div>
                          <div className="text-right">
                             <p className="text-zinc-600 text-[9px] font-black uppercase tracking-widest mb-1">Visibility</p>
                             <p className="text-purple-500 text-xl font-mono font-black">0.00%</p>
                          </div>
                       </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                       {parseExploitSteps(exploitPlan).map((step, idx) => (
                         <div key={idx} className={`p-8 bg-zinc-950 border rounded-[2.5rem] flex flex-col gap-6 group/step transition-all hover:-translate-y-2 ${step.risk === 'CRITICAL' ? 'border-red-600 shadow-[0_0_30px_rgba(220,38,38,0.2)]' : step.risk === 'HIGH' ? 'border-orange-600/50' : 'border-zinc-800 hover:border-blue-500/50'}`}>
                            <div className="flex justify-between items-start">
                               <span className="text-[14px] font-black text-zinc-700 group-hover/step:text-white transition-colors">STEP_0{idx+1}</span>
                               <span className={`text-[8px] font-black px-2 py-0.5 rounded-full border ${step.risk === 'CRITICAL' ? 'bg-red-600 text-white border-red-600' : step.risk === 'HIGH' ? 'bg-orange-600/10 text-orange-500 border-orange-500/20' : 'bg-green-600/10 text-green-500 border-green-500/20'}`}>{step.risk}</span>
                            </div>
                            <div className="space-y-2">
                               <h5 className="text-white text-[12px] font-black uppercase tracking-widest truncate">{step.title}</h5>
                               <p className="text-zinc-500 text-[10px] font-medium leading-relaxed italic">{step.objective}</p>
                            </div>
                            <div className="mt-auto space-y-4 pt-4 border-t border-zinc-900">
                               <div className="space-y-1">
                                  <p className="text-zinc-600 text-[7px] font-black uppercase tracking-widest">Payload</p>
                                  <p className="text-zinc-400 text-[9px] font-mono truncate">{step.payload}</p>
                               </div>
                               <div className="space-y-1">
                                  <p className="text-zinc-600 text-[7px] font-black uppercase tracking-widest">Expected Result</p>
                                  <p className="text-zinc-400 text-[9px] leading-tight">{step.result}</p>
                               </div>
                            </div>
                         </div>
                       ))}
                    </div>
                  </div>
                )}

                {mockupUrl && (
                  <div className={`rounded-[4rem] border ${isGithub ? 'border-purple-900/40' : 'border-zinc-800'} overflow-hidden shadow-3xl relative group/img transition-all hover:scale-[1.01]`}>
                     <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent z-10 opacity-80"></div>
                     <img src={mockupUrl} className="w-full opacity-90 transition-all duration-[5000ms] group-hover/img:scale-105" alt="Neural HUD" />
                     <div className="absolute bottom-10 left-10 z-20 flex flex-col gap-2">
                        <p className={`text-[10px] font-black text-white uppercase tracking-[1em] bg-black/80 px-8 py-3 rounded-full border ${isGithub ? 'border-purple-600' : 'border-zinc-800'} backdrop-blur-md`}>
                           {isGithub ? 'GitHub_Ghost_HUD' : 'Tactical_Operation_HUD'}
                        </p>
                        {isGithub && <p className="text-[8px] text-purple-400 font-black uppercase tracking-widest ml-4">Neural Mirror Reconstruction: Verified</p>}
                     </div>
                  </div>
                )}

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                   <div className={`lg:col-span-2 p-20 ${isGithub ? 'bg-purple-950/5 border-purple-900/20 shadow-[0_0_80px_rgba(168,85,247,0.08)]' : 'bg-zinc-900/5 border-zinc-900 shadow-inner'} border rounded-[5rem] relative group/content transition-all hover:bg-zinc-900/10`}>
                      <div className="absolute top-12 right-16 flex items-center gap-4">
                         <div className={`w-2.5 h-2.5 rounded-full ${isGithub ? 'bg-purple-500 shadow-[0_0_10px_rgba(168,85,247,1)]' : 'bg-blue-500'} animate-pulse`}></div>
                         <span className={`text-[10px] font-black ${isGithub ? 'text-purple-500' : 'text-blue-500'} uppercase tracking-[0.5em]`}>
                           {isGithub ? 'Ghost_Active' : 'Projection_Steady'}
                         </span>
                      </div>
                      <div className={`prose prose-invert max-w-none font-mono text-[16px] leading-relaxed ${isGithub ? 'text-purple-100/90' : 'text-zinc-300'} whitespace-pre-wrap selection:bg-purple-600/40`}>
                        {projectionData}
                      </div>
                   </div>
                   <div className="space-y-10">
                      {scanResult && (
                        <div className={`p-10 ${isGithub ? 'bg-purple-950/10 border-purple-900/30' : 'bg-zinc-900/20 border-zinc-800'} border rounded-[3rem] relative overflow-hidden group/audit`}>
                           <h4 className={`text-[10px] font-black uppercase tracking-[0.8em] mb-8 ${isGithub ? 'text-purple-400' : 'text-zinc-500'}`}>
                             {isGithub ? 'Ghost_Logic_Audit' : 'Surface_Audit'}
                           </h4>
                           <div className={`prose prose-invert text-[12px] font-mono leading-relaxed whitespace-pre-wrap line-clamp-[20] ${isGithub ? 'text-purple-200/60' : 'text-zinc-500'}`}>
                              {scanResult}
                           </div>
                        </div>
                      )}
                      {citations.length > 0 && (
                        <div className="space-y-4">
                          <h4 className="text-zinc-700 text-[9px] font-black uppercase tracking-[1em] ml-4">Grounding_Nodes</h4>
                          {citations.map((c, i) => (
                            <a key={i} href={c.web?.uri} target="_blank" rel="noopener noreferrer" className={`block p-8 border rounded-[2.5rem] transition-all group backdrop-blur-sm ${isGithub ? 'bg-purple-900/10 border-purple-800/20 hover:border-purple-500/40' : 'bg-zinc-900/10 border-zinc-800 hover:border-blue-500/40'}`}>
                              <p className={`text-[11px] font-black truncate uppercase tracking-widest mb-1 ${isGithub ? 'text-purple-200' : 'text-zinc-300'}`}>{c.web?.title}</p>
                              <p className="text-zinc-700 text-[8px] truncate italic font-mono">{c.web?.uri}</p>
                            </a>
                          ))}
                        </div>
                      )}
                   </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <style>{`
        .header-rain-container::before {
          content: 'PROTOCOL_RED_SPEAR MISSION_PLAN_ACTIVE THREAT_MATRIX_SYNC BREACH_STABILITY_0.94';
          position: absolute;
          top: -200px;
          left: 0;
          width: 100%;
          height: 400%;
          font-family: 'JetBrains Mono', monospace;
          font-size: 10px;
          font-weight: 900;
          color: #dc2626;
          overflow: hidden;
          line-height: 1.6;
          display: flex;
          flex-wrap: wrap;
          justify-content: space-around;
          animation: rain 12s linear infinite;
          opacity: 0.3;
        }
        .ghost-rain-container::before {
          content: 'PROTOCOL_GHOST_INIT GITHUB_STEALTH_BYPASS NEURAL_SANITIZER_ACTIVE IDENTITY_ENTROPY_1.0';
          position: absolute;
          top: -200px;
          left: 0;
          width: 100%;
          height: 400%;
          font-family: 'JetBrains Mono', monospace;
          font-size: 10px;
          font-weight: 900;
          color: #a855f7;
          overflow: hidden;
          line-height: 1.6;
          display: flex;
          flex-wrap: wrap;
          justify-content: space-around;
          animation: rain 15s linear infinite;
          opacity: 0.5;
        }
        @keyframes rain { from { transform: translateY(0); } to { transform: translateY(-25%); } }
      `}</style>
    </div>
  );
};
