
import React, { useState, useEffect } from 'react';
import { AppState } from '../types';

interface HeaderProps {
  state: AppState;
  onUrlChange: (url: string) => void;
}

export const Header: React.FC<HeaderProps> = ({ state, onUrlChange }) => {
  const [inputValue, setInputValue] = useState(state.currentUrl);

  useEffect(() => {
    setInputValue(state.currentUrl);
  }, [state.currentUrl]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let url = inputValue.trim();
    if (!url) return;
    if (!url.startsWith('http')) url = `https://${url}`;
    onUrlChange(url);
  };

  const riskColor = state.riskScore < 20 ? 'text-green-500' : state.riskScore < 50 ? 'text-yellow-500' : 'text-red-500';

  return (
    <header className="h-20 border-b border-zinc-900 flex items-center px-8 bg-black/50 backdrop-blur-xl sticky top-0 z-50">
      <div className="flex items-center gap-8 flex-1">
        <div className="flex gap-2">
          <button className="w-10 h-10 flex items-center justify-center rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-white transition-all shadow-lg active:scale-95">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M15 19l-7-7 7-7" /></svg>
          </button>
          <button className="w-10 h-10 flex items-center justify-center rounded-lg bg-zinc-900 border border-zinc-800 text-zinc-500 hover:text-white transition-all shadow-lg active:scale-95">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="flex-1 max-w-2xl">
          <div className="relative flex items-center">
            <input 
              type="text" 
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="w-full bg-zinc-900/50 border border-zinc-800 rounded-xl pl-6 pr-12 py-3 text-[13px] text-zinc-100 outline-none focus:border-blue-500/50 transition-all font-mono"
              placeholder="Secure node address..."
              disabled={!state.isActive}
            />
            <div className="absolute right-4">
              <div className={`w-2 h-2 rounded-full ${state.isActive ? 'bg-green-500 animate-pulse' : 'bg-zinc-800'}`}></div>
            </div>
          </div>
        </form>

        <div className="flex items-center gap-6 px-6 border-l border-zinc-900">
          <div className="text-right">
             <p className="text-[8px] text-zinc-600 font-black uppercase tracking-widest mb-1">Detection Risk</p>
             <div className="flex items-center gap-3">
               <div className="w-24 h-1.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                 <div 
                    className={`h-full transition-all duration-1000 ${state.riskScore < 20 ? 'bg-green-500' : state.riskScore < 50 ? 'bg-yellow-500' : 'bg-red-500'}`}
                    style={{ width: `${state.riskScore}%` }}
                 ></div>
               </div>
               <span className={`text-[10px] font-black mono w-8 ${riskColor}`}>{state.riskScore}%</span>
             </div>
          </div>
          <div className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center relative overflow-hidden group">
             <div className="absolute inset-0 bg-blue-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
             <div className="w-5 h-5 bg-gradient-to-br from-zinc-400 to-zinc-600 rounded rotate-45"></div>
          </div>
        </div>
      </div>
    </header>
  );
};
