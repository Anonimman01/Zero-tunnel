
import React, { useState } from 'react';
import { SecurityEvent, GhostAction } from '../types';

interface SecurityLogProps {
  logs: SecurityEvent[];
  actions: GhostAction[];
}

export const SecurityLog: React.FC<SecurityLogProps> = ({ logs, actions }) => {
  const [activeTab, setActiveTab] = useState<'security' | 'intercepted' | 'actions'>('security');

  const interceptedLogs = logs.filter(l => l.type === 'PROBE_INTERCEPTED');
  const systemLogs = logs.filter(l => l.type !== 'PROBE_INTERCEPTED');

  return (
    <div className="h-full flex flex-col border-l border-zinc-800">
      <div className="flex border-b border-zinc-800 bg-zinc-950/80 sticky top-0 z-10">
        <button 
          onClick={() => setActiveTab('security')}
          className={`flex-1 py-3 text-[9px] font-bold tracking-widest uppercase transition-colors ${activeTab === 'security' ? 'text-green-500 border-b-2 border-green-500' : 'text-zinc-600 hover:text-zinc-400'}`}
        >
          System
        </button>
        <button 
          onClick={() => setActiveTab('intercepted')}
          className={`flex-1 py-3 text-[9px] font-bold tracking-widest uppercase transition-colors ${activeTab === 'intercepted' ? 'text-blue-500 border-b-2 border-blue-500' : 'text-zinc-600 hover:text-zinc-400'}`}
        >
          Shields ({interceptedLogs.length})
        </button>
        <button 
          onClick={() => setActiveTab('actions')}
          className={`flex-1 py-3 text-[9px] font-bold tracking-widest uppercase transition-colors ${activeTab === 'actions' ? 'text-orange-500 border-b-2 border-orange-500' : 'text-zinc-600 hover:text-zinc-400'}`}
        >
          Biometrics
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-black/40">
        {activeTab === 'security' ? (
          systemLogs.length > 0 ? systemLogs.map((log) => (
            <div key={log.id} className={`p-2 border-l-2 bg-zinc-900/40 border-zinc-800 text-[10px] transition-all hover:translate-x-1 ${
              log.severity === 'critical' ? 'border-red-600 bg-red-950/10' : 
              log.severity === 'high' ? 'border-orange-600' : 'border-zinc-700'
            }`}>
              <div className="flex justify-between items-start mb-1">
                <span className={`font-bold uppercase ${
                  log.severity === 'critical' ? 'text-red-500' : 
                  log.severity === 'high' ? 'text-orange-500' : 'text-zinc-400'
                }`}>{log.type}</span>
                <span className="text-[8px] text-zinc-600">{log.timestamp}</span>
              </div>
              <p className="text-zinc-500 leading-tight">{log.source}</p>
            </div>
          )) : (
            <div className="h-full flex flex-col items-center justify-center opacity-20 italic text-[10px] uppercase tracking-widest">
              Silence in sector
            </div>
          )
        ) : activeTab === 'intercepted' ? (
          interceptedLogs.length > 0 ? interceptedLogs.map((log) => (
            <div key={log.id} className="p-3 bg-blue-900/5 border border-blue-900/20 rounded text-[10px] animate-in slide-in-from-right-2 duration-300">
              <div className="flex justify-between items-center mb-1">
                <span className="text-blue-400 font-black uppercase">Probe_Interception</span>
                <span className="text-[8px] text-zinc-600">{log.timestamp}</span>
              </div>
              <p className="text-zinc-400">{log.source}</p>
              <div className="mt-2 text-[8px] text-blue-500/60 font-bold uppercase italic">Status: Neutralized by Ghost Protocol</div>
            </div>
          )) : (
            <div className="h-full flex flex-col items-center justify-center opacity-20 italic text-[10px] uppercase tracking-widest">
              Shields Nominal
            </div>
          )
        ) : (
          actions.length > 0 ? actions.map((action, idx) => (
            <div key={idx} className="p-2 bg-zinc-900/30 border border-zinc-800/50 rounded flex flex-col gap-1">
              <div className="flex justify-between items-center">
                <span className="text-[9px] font-bold text-orange-400 uppercase">{action.type} Jittered</span>
                <span className="text-[8px] text-zinc-600">{new Date(action.timestamp).toLocaleTimeString([], { hour12: false, second: '2-digit' })}</span>
              </div>
              <div className="text-[8px] text-zinc-500 mono">
                <p>COORDS: {action.coordinates?.x.toFixed(0)}, {action.coordinates?.y.toFixed(0)}</p>
                <p>BIOMETRIC_GAP: {action.delayApplied}ms</p>
                <p>TARGET: &lt;{action.target}&gt;</p>
              </div>
            </div>
          )) : (
            <div className="h-full flex flex-col items-center justify-center opacity-20 italic text-[10px] uppercase tracking-widest">
              No activity
            </div>
          )
        )}
      </div>

      <div className="p-3 border-t border-zinc-800 bg-zinc-950 text-[8px] text-zinc-700 uppercase tracking-widest font-bold flex justify-between">
        <span>Active_Nodes: {logs.length}</span>
        <span className="text-green-500/50 animate-pulse">Live_Sync</span>
      </div>
    </div>
  );
};
