
import React from 'react';
import { AppState } from '../types';

interface SidebarProps {
  state: AppState;
  onInit: () => void;
  onBurn: () => void;
  isInitializing: boolean;
  onConfigChange: (config: AppState['stealthConfig']) => void;
  hasSelectedKey: boolean;
  onOpenSelectKey: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  state, 
  onInit, 
  onBurn, 
  isInitializing, 
  onConfigChange,
  hasSelectedKey,
  onOpenSelectKey 
}) => {
  const toggle = (key: keyof AppState['stealthConfig']) => {
    onConfigChange({
      ...state.stealthConfig,
      [key]: !state.stealthConfig[key]
    });
  };

  const activeShields = Object.values(state.stealthConfig).filter(v => v).length;
  const integrity = Math.round((activeShields / Object.keys(state.stealthConfig).length) * 100);

  return (
    <aside className="w-80 bg-zinc-950 flex flex-col border-r border-zinc-900 p-8 overflow-y-auto z-20 scrollbar-hide">
      <div className="mb-12">
        <div className="flex items-center gap-3 mb-2">
          <div className={`w-3 h-3 rounded-full ${state.isActive ? 'bg-green-500 animate-pulse' : 'bg-zinc-800'}`}></div>
          <h1 className="text-xl font-black text-white tracking-tighter uppercase italic leading-none">GHOST_CORE</h1>
        </div>
        <p className="text-[9px] text-zinc-600 uppercase tracking-[0.2em] font-bold">Neural Breach Protocol v5.2</p>
      </div>

      <div className="space-y-10 flex-1">
        {!hasSelectedKey ? (
          <div className="p-8 border border-orange-900/50 bg-orange-950/10 rounded-2xl text-center space-y-6 animate-in fade-in zoom-in-95 duration-500">
            <div className="flex justify-center">
               <div className="w-12 h-12 bg-orange-500/20 rounded-full flex items-center justify-center border border-orange-500/30">
                  <svg className="w-6 h-6 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
               </div>
            </div>
            <h3 className="text-[10px] font-black text-orange-500 tracking-[0.2em] uppercase">Auth Required</h3>
            <p className="text-[9px] text-zinc-500 leading-relaxed font-black uppercase tracking-widest">
              Gemini 3 Pro & Imagen modules require an active billing project key.
            </p>
            <button 
              onClick={onOpenSelectKey}
              className="w-full py-4 bg-orange-600 hover:bg-orange-500 text-white text-[11px] font-black transition-all rounded-xl uppercase tracking-widest shadow-lg shadow-orange-900/20 active:scale-95"
            >
              Select Paid Project
            </button>
            <a 
              href="https://ai.google.dev/gemini-api/docs/billing" 
              target="_blank" 
              rel="noopener noreferrer"
              className="block text-[8px] text-zinc-600 hover:text-orange-400 underline uppercase tracking-widest font-black transition-colors"
            >
              Setup Billing Documentation
            </a>
          </div>
        ) : !state.isActive ? (
          <div className="p-8 border border-zinc-900 bg-zinc-900/20 rounded-2xl text-center space-y-4">
            <button 
              onClick={onInit}
              disabled={isInitializing}
              className="w-full py-4 bg-zinc-900 hover:bg-zinc-800 text-white disabled:opacity-30 text-[10px] font-black transition-all rounded-xl uppercase tracking-widest border border-zinc-800"
            >
              {isInitializing ? 'Generating...' : 'Start Handshake'}
            </button>
            <p className="text-[8px] text-zinc-700 font-bold uppercase tracking-widest">Local Session Isolation Active</p>
          </div>
        ) : (
          <div className="space-y-12">
            <section>
               <div className="flex justify-between items-center mb-3">
                 <h3 className="text-[9px] font-black text-zinc-600 tracking-[0.3em] uppercase italic">Shield Strength</h3>
                 <span className="text-[10px] font-black text-green-500 mono">{integrity}%</span>
               </div>
               <div className="h-1 bg-zinc-900 rounded-full overflow-hidden">
                 <div className="h-full bg-green-500 transition-all duration-700" style={{ width: `${integrity}%` }}></div>
               </div>
            </section>

            <section>
              <h3 className="text-[10px] font-black text-zinc-600 mb-6 tracking-widest uppercase border-b border-zinc-900 pb-2">Hardware Masking</h3>
              <div className="space-y-5">
                {[
                  { id: 'canvasPoisoning', label: 'Canvas Noise', desc: 'Synthetic pixels' },
                  { id: 'webrtcMasking', label: 'WebRTC Shroud', desc: 'IP Isolation' },
                  { id: 'fontMasking', label: 'Font Shield', desc: 'Profile Flattening' },
                  { id: 'audioPoisoning', label: 'Audio Jitter', desc: 'Context Masking' }
                ].map((item) => (
                  <div key={item.id} className="group cursor-pointer" onClick={() => toggle(item.id as any)}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-black text-zinc-500 group-hover:text-zinc-200 transition-colors uppercase">{item.label}</span>
                      <div className={`w-10 h-5 rounded-full relative transition-colors ${state.stealthConfig[item.id as keyof AppState['stealthConfig']] ? 'bg-blue-600' : 'bg-zinc-900'}`}>
                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${state.stealthConfig[item.id as keyof AppState['stealthConfig']] ? 'left-6' : 'left-1'}`}></div>
                      </div>
                    </div>
                    <p className="text-[7px] text-zinc-700 uppercase font-black leading-tight tracking-widest">{item.desc}</p>
                  </div>
                ))}
              </div>
            </section>

            <section>
              <h3 className="text-[10px] font-black text-zinc-600 mb-6 tracking-widest uppercase border-b border-zinc-900 pb-2">Intelligence</h3>
              <div className="space-y-5">
                {[
                  { id: 'autoMirror', label: 'Adaptive Handshake', desc: 'Auto-bypass X-Frame' },
                  { id: 'autoRotate', label: 'ID Rotation', desc: 'Cycle ID 180s' },
                  { id: 'inputJitter', label: 'Biometric Chaos', desc: 'Human Pattern Mask' }
                ].map((item) => (
                  <div key={item.id} className="group cursor-pointer" onClick={() => toggle(item.id as any)}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-black text-zinc-500 group-hover:text-zinc-200 transition-colors uppercase">{item.label}</span>
                      <div className={`w-10 h-5 rounded-full relative transition-colors ${state.stealthConfig[item.id as keyof AppState['stealthConfig']] ? 'bg-orange-600' : 'bg-zinc-900'}`}>
                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full transition-all ${state.stealthConfig[item.id as keyof AppState['stealthConfig']] ? 'left-6' : 'left-1'}`}></div>
                      </div>
                    </div>
                    <p className="text-[7px] text-zinc-700 uppercase font-black leading-tight tracking-widest">{item.desc}</p>
                  </div>
                ))}
              </div>
            </section>
          </div>
        )}
      </div>

      <div className="mt-auto pt-8 border-t border-zinc-900">
        <button 
          onClick={onBurn}
          className="w-full py-4 bg-zinc-950 hover:bg-red-950/20 border border-zinc-900 hover:border-red-900 text-zinc-800 hover:text-red-500 text-[10px] font-black transition-all rounded-2xl uppercase tracking-[0.3em]"
        >
          ☢ Terminate Session
        </button>
      </div>
    </aside>
  );
};
