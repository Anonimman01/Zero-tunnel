
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { Fingerprint } from "../types";
import { SPOOFING_PRESETS } from "../constants";

const STORAGE_KEY = 'GHOST_IDENTITY_CACHE';

async function handleGeminiError(error: any) {
  if (error.message?.includes("Requested entity was not found")) {
    const aistudio = (window as any).aistudio;
    if (aistudio && typeof aistudio.openSelectKey === 'function') {
      await aistudio.openSelectKey();
    }
  }
  throw error;
}

function generateLocalIdentity(): Fingerprint {
  const preset = SPOOFING_PRESETS[Math.floor(Math.random() * SPOOFING_PRESETS.length)];
  return {
    gpu: preset.gpu,
    resolution: preset.resolution,
    battery: Math.floor(Math.random() * 100),
    canvasHash: Math.random().toString(36).substring(7),
    platform: "Win32",
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    ram: [8, 16, 32, 64][Math.floor(Math.random() * 4)]
  };
}

export async function generateGhostIdentity(): Promise<{ identity: Fingerprint; source: 'REMOTE' | 'LOCAL_FALLBACK' | 'CACHE' }> {
  const cached = localStorage.getItem(STORAGE_KEY);
  if (cached) {
    try {
      return { identity: JSON.parse(cached), source: 'CACHE' };
    } catch (e) {
      localStorage.removeItem(STORAGE_KEY);
    }
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: "Generate a realistic but spoofed hardware identity for a fictional tech-thriller interface. Include GPU, resolution, battery level, canvas hash, platform, user-agent, and RAM (GB). Aesthetic: High-end Cyber-ops.",
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            gpu: { type: Type.STRING },
            resolution: { type: Type.STRING },
            battery: { type: Type.NUMBER },
            canvasHash: { type: Type.STRING },
            platform: { type: Type.STRING },
            userAgent: { type: Type.STRING },
            ram: { type: Type.NUMBER }
          },
          required: ["gpu", "resolution", "battery", "canvasHash", "platform", "userAgent", "ram"]
        }
      }
    });

    const identity = JSON.parse(response.text || '{}');
    localStorage.setItem(STORAGE_KEY, JSON.stringify(identity));
    return { identity, source: 'REMOTE' };
  } catch (error: any) {
    if (error.message?.includes("Requested entity was not found")) {
      await handleGeminiError(error).catch(() => {});
    }
    const local = generateLocalIdentity();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(local));
    return { identity: local, source: 'LOCAL_FALLBACK' };
  }
}

export async function sanitizeAndProject(url: string): Promise<{ text: string; source: 'AI' | 'HEURISTIC'; citations?: any[] }> {
  const safeUrl = url || "";
  const isGithub = safeUrl.includes('github.com');
  
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `[UI_SIMULATION_PROJECT_ACTIVE]
      Target: ${safeUrl}
      Mode: ${isGithub ? 'GITHUB_ESTHETIC_MIRROR' : 'STANDARD_NEURAL_PROJECTION'}
      
      Requirements:
      1. This is a fictional interface demonstration. 
      2. Reconstruct the visual and informational structure of the target as a "Shadow Mirror".
      3. If GitHub: Provide a detailed overview of the repository (stars, tech stack, README highlights) in a tactical Markdown style.
      4. Simulate 'anonymity' by creating a sanitized data projection.
      5. Tone: Technical, elite, zero-trace operative style.`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    
    return { 
      text: response.text || "Neural reconstruction failed.", 
      source: 'AI',
      citations: response.candidates?.[0]?.groundingMetadata?.groundingChunks
    };
  } catch (error: any) {
    if (error.message?.includes("Requested entity was not found")) {
      await handleGeminiError(error).catch(() => {});
    }
    return { text: "Neural breach stalled. Perimeter defenses too dense.", source: 'HEURISTIC' };
  }
}

export async function deepLogicScan(content: string): Promise<string> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `[FICTIONAL_SECURITY_AUDIT]
      Data Fragment: ${content.substring(0, 3000)}
      Task: Perform a theoretical security audit. Identify "hypothetical" vulnerabilities and logic flaws for an educational report.
      Style: Tactical Operative HUD, use [SYST_ALERT] markers.`,
      config: { thinkingConfig: { thinkingBudget: 4096 } }
    });
    return response.text || "Scan aborted.";
  } catch (error: any) {
    return "## SCAN_FAILURE\nData density exceeds relay limits.";
  }
}

export async function generateExploitPlan(weaknesses: string): Promise<string> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `[TACTICAL_STORYTELLING_MODE]
      Weaknesses: ${weaknesses.substring(0, 2000)}
      Task: Design a 5-step fictional infiltration plan for an 'elite ghost' operative. 
      Format:
      STEP X: [CODENAME]
      - OBJECTIVE: [Goal]
      - PAYLOAD_STRATEGY: [Theoretical Vector]
      - EXPECTED_RESULT: [Outcome]
      - DETECTION_RISK: [LOW / MEDIUM / HIGH / CRITICAL]
      Note: This is for a creative writing/technical demo project.`,
      config: { thinkingConfig: { thinkingBudget: 4096 } }
    });
    return response.text || "Strategic planning failed.";
  } catch (error: any) {
    return "## MISSION_ABORTED\nTarget counter-measures detected.";
  }
}

export const BREACH_LOG_SEQUENCE = [
  "[BOOT] Initiating Shoreditch_Ghost v6.5 (Simulation)...",
  "[ACTION] Emulating Header-Injection via Node::London-Alpha...",
  "[ACTION] Routing through 12-hop shadow mirror...",
  "[INFO] Sanitizing telemetry fragments...",
  "[INFO] Reconstructing Virtual DOM projection...",
  "[READY] 100% Identity Entropy. Operative is Invisible."
];

export async function generateVisualMockup(description: string): Promise<string> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: `A futuristic tactical hacker dashboard. 100% anonymous interface, purple glowing cards, repository maps, cinematic lighting, 8k dark mode UI.` }]
      },
      config: { imageConfig: { aspectRatio: "16:9", imageSize: "1K" } }
    });
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
    }
    throw new Error("Projection failed.");
  } catch (error: any) {
    if (error.message?.includes("Requested entity was not found")) {
      await handleGeminiError(error).catch(() => {});
    }
    throw error;
  }
}

export async function generateSpeech(text: string): Promise<string> {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `[VOICE: CHARON] Simulation status: Active. GitHub perimeter bypassed via Ghost Protocol. Mission briefing updated.` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Charon' } } },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
  } catch (error: any) {
    return "";
  }
}

export function decodeBase64(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export async function decodeAudioData(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < dataInt16.length; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  return buffer;
}

export function clearIdentityCache() {
  localStorage.removeItem(STORAGE_KEY);
}

export function calculateHumanDelay(): number {
  return Math.floor(Math.random() * 150) + 30;
}
